const router = require('express').Router();
const productController = require('../controllers/productControllers');

// create product api
router.post('/create_product', productController.createProduct);

// get all products api
router.get('/get_products', productController.getAllProducts);






module.exports = router;
